sap.ui.define([
		'jquery.sap.global',
		'./Formatter',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/json/JSONModel',
		'sap/ui/model/Sorter',
	], function(jQuery, Formatter, Controller, JSONModel, Sorter) {
	"use strict";

	var TableController = Controller.extend("sap.m.sample.Table.Table", {

		onInit: function () {
			
			this._bIdSort = false;
			// set explored app's demo model on this sample
			var oModel = new JSONModel(jQuery.sap.getModulePath("sap.ui.demo.mock", "/products.json"));
			this.getView().setModel(oModel);
		},

    	onSortCategory: function() {
    		var oSorter = new Sorter("Category", this._bIdSort);
    		var oTable = sap.ui.getCore().byId("__xmlview1--idProductsTable");
    		oTable.getBinding("items").sort(oSorter);
    		this._bIdSort = !this._bIdSort;
    	},
    	
    	onGroupBySupplier: function() {
    		var oSorter = new Sorter("SupplierName", false, true);
    		var oTable = sap.ui.getCore().byId("__xmlview1--idProductsTable");
    		oTable.getBinding("items").sort(oSorter);
    	},
    	
		onPopinLayoutChanged: function() {
			var oTable = this.byId("idProductsTable");
			var oComboBox = this.byId("idPopinLayout");
			var sPopinLayout = oComboBox.getSelectedKey();
			switch (sPopinLayout) {
				case "Block":
					oTable.setPopinLayout(sap.m.PopinLayout.Block);
					break;
				case "GridLarge":
					oTable.setPopinLayout(sap.m.PopinLayout.GridLarge);
					break;
				case "GridSmall":
					oTable.setPopinLayout(sap.m.PopinLayout.GridSmall);
					break;
				default:
					oTable.setPopinLayout(sap.m.PopinLayout.Block);
					break;
			}
		},

		onSelectionFinish: function(oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems");
			var oTable = this.byId("idProductsTable");
			var aSticky = aSelectedItems.map(function(oItem) {
				return oItem.getKey();
			});

			oTable.setSticky(aSticky);
		},

		onToggleInfoToolbar: function(oEvent) {
			var oTable = this.byId("idProductsTable");
			oTable.getInfoToolbar().setVisible(!oEvent.getParameter("pressed"));
		}
	});


	return TableController;

});
