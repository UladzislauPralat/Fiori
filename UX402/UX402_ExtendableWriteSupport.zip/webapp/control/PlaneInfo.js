sap.ui.define([
	"sap/ui/core/Control",
	"com/sap/training/ux402/fullscreenUX402_FullScreenExercise/control/PlaneInfoRenderer"],
	function(Control,PlaneInfoRenderer) {
		"use strict";
		
		return Control.extend("com.sap.training.ux402.fullscreenUX402_FullScreenExercise.control.PlaneInfo", {
			metadata: {
				properties: {
					"seatsMax": { type: "string"},
					"seatsOcc": { type: "string"},
					"planeType": { type: "string"}					
				}
			},
			
			renderer: PlaneInfoRenderer
		});
	});