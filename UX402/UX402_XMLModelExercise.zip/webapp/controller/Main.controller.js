sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.sap.training.ux402.xmlmodel.UX402_XMLModelExercise.controller.Main", {

	});
});