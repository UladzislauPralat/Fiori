sap.ui.define([
	"com/sap/training/ux402/masterdetail/UX402_MasterDetailExercise/controller/BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("com.sap.training.ux402.masterdetail.UX402_MasterDetailExercise.controller.Main", {

	});
});