sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.sap.training.ux402.messages.UX402_WorkingWithMessages.controller.Main", {
		onInit: function () {
			var oView = this.getView();
			oView.setModel(new JSONModel(), "input");
			var oMessageModel = sap.ui.getCore().getMessageManager().getMessageModel();
			oView.byId("idMsgTable").setModel(oMessageModel, "message");
		},

		onShowCarrier: function () {
			var oMessageManager = sap.ui.getCore().getMessageManager();
			var oMessageProcessor = new sap.ui.core.message.ControlMessageProcessor();
			oMessageManager.registerMessageProcessor(oMessageProcessor);

			oMessageManager.addMessages(
				new sap.ui.core.message.Message({
					message: "Button Pressed",
					type: sap.ui.core.MessageType.Success,
					processor: oMessageProcessor
				})
			);
			
			var oView = this.getView();
			var oInputData = oView.getModel("input").getData();
			oView.bindElement({ path: "travel>/CarrierCollection('" + oInputData.AirLineID + "')" });
		},
		
		onDeleteMessages: function() {
			var oMessageManager = sap.ui.getCore().getMessageManager();
			oMessageManager.removeAllMessages();
		}

	});
});