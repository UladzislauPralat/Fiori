sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel"
], function (Controller, MessageToast, MessageBox, JSONModel) {
	"use strict";

	return Controller.extend("deep.insert.UX402_DeepInsertExercise.controller.Main", {

		onPress: function (evt) {
			var json = {
				"CurrencyCode": "EUR",
				"OrderToItems": [{
					"ProductId": "HT-1000",
					"Note": "EPM DG: SO ID 0500000000 Item 0000000010",
					"CurrencyCode": "EUR",
					"GrossAmount": "1137.64",
					"GrossAmountExt": "1137.6400",
					"NetAmount": "956.00",
					"NetAmountExt": "956.0000",
					"TaxAmount": "181.64",
					"TaxAmountExt": "181.6400",
					"DeliveryDate": "2018-08-26T04:00:00.0000000",
					"Quantity": "1",
					"QuantityUnit": "EA"
				}]
			};
			this.createModel = new JSONModel(json);
			this.getView().setModel(this.createModel, "createCollection");
			var oSOData = this.getView().getModel("createCollection").getData();

			var oModel = this.getOwnerComponent().getModel();
			var mParameters = {
				success: this._handleCreateSuccess,
				error: this._handleCreateError
			};
			oModel.create("/SalesOrderSet", oSOData, mParameters);
		},

		_handleCreateSuccess: function (oData, response) {
			MessageBox.alert("Order created. Order number is: " + oData.SoId);
		},

		_handleCreateError: function (oError) {
			if (oError) {
				if (oError.responseText) {
					var oErrorMessage = JSON.parse(oError.responseText);
					MessageBox.alert("Order was not created due to: " +
						oErrorMessage.error.message.value);
				}
			}
		}

	});
});