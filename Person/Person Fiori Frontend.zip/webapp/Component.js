jQuery.sap.declare("uladzislau.pralatperson.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("uladzislau.pralatperson.Component", {
	metadata: {
		"manifest": "json"
	}
});