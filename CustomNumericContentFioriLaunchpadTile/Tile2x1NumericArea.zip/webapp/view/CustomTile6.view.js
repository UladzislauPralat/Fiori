// Copyright (c) 2009-2014 SAP SE, All Rights Reserved

(function () {
	"use strict";
	/*global jQuery, sap */
	/*jslint nomen: true */

	sap.ui.jsview("view.CustomTile6", {
		getControllerName: function () {
			return "view.CustomTile6";
		},
		createContent: function (oController) {
			this.setHeight('100%');
			this.setWidth('100%');
		},
		getTileControl: function () {
			jQuery.sap.require('sap.m.GenericTile');
			//			jQuery.sap.require('sap.suite.ui.microchart.ComparisonMicroChart');
			//			jQuery.sap.require('sap.suite.ui.microchart.DeltaMicroChart');
			//			jQuery.sap.require('sap.suite.ui.microchart.BulletMicroChart');
			//			jQuery.sap.require('sap.suite.ui.microchart.ColumnMicroChart');			
			//			jQuery.sap.require('sap.suite.ui.microchart.LineMicroChart');			
			jQuery.sap.require('sap.suite.ui.microchart.AreaMicroChart');
			//			jQuery.sap.require('sap.suite.ui.commons.NumericContent');

			var oController = this.getController();
			//			var itemTemplate = new sap.m.StandardListItem({
			//				icon: "{Icon}",
			//				/*				description:"{Naam}",  */
			//				title: "{Naam}"
			//			});

			//			var data1 = new sap.suite.ui.microchart.ComparisonMicroChartData({
			//				title: "{/data/emp/month1}",
			//				value: "{/data/emp/value1}",
			//				/*10*/
			//				color: "{/data/emp/color1}"
			//			});
			//			var data2 = new sap.suite.ui.microchart.ComparisonMicroChartData({
			//				title: "{/data/emp/month2}",
			//				value: "{/data/emp/value2}",
			//				/*20*/
			//				color: "{/data/emp/color2}"
			//			});
			//			var data3 = new sap.suite.ui.microchart.ComparisonMicroChartData({
			//				title: "{/data/emp/month3}",
			//				value: "{/data/emp/value3}",
			//				/*-10, */
			//				color: "{/data/emp/color3}"
			//			});

			//			var actual = new sap.suite.ui.microchart.BulletMicroChartData({
			//				value: '{/data/emp/actual}',
			//				color: '{/data/emp/color}'
			//			});

			//          var leftbottomlabel = new sap.suite.ui.microchart.ColumnMicroChartLabel({
			//			label : "28",
			//			color : "Error"
			//			});			
			//           var rightbottomlabel = new sap.suite.ui.microchart.ColumnMicroChartLabel({
			//			label : "27",
			//			color : "Error"
			//			});						

			// var point1 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point1XValue}", 
			// 	y: "{/data/emp/point1YValue}"
			// });
			// var point2 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point2XValue}", 
			// 	y: "{/data/emp/point2YValue}"
			// });	
			// var point3 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point3XValue}", 
			// 	y: "{/data/emp/point3YValue}"
			// });	
			// var point4 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point4XValue}", 
			// 	y: "{/data/emp/point4YValue}"
			// });	
			// var point5 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point5XValue}",  
			// 	y: "{/data/emp/point5YValue}"
			// });	
			// var point6 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point6XValue}",   
			// 	y: "{/data/emp/point6YValue}"
			// });
			// var point7 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point7XValue}", 
			// 	y: "{/data/emp/point7YValue}"
			// });
			// var point8 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point8XValue}", 
			// 	y: "{/data/emp/point8YValue}"
			// });	
			// var point9 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point9XValue}", 
			// 	y: "{/data/emp/point9YValue}"
			// });	
			// var point10 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point10XValue}", 
			// 	y: "{/data/emp/point10YValue}"
			// });	
			// var point11 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point11XValue}", 
			// 	y: "{/data/emp/point11YValue}"
			// });	
			// var point12 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point12XValue}", 
			// 	y: "{/data/emp/point12YValue}"
			// });				
			// var point13 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point13XValue}", 
			// 	y: "{/data/emp/point13YValue}"
			// });
			// var point14 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point14XValue}",  
			// 	y: "{/data/emp/point14YValue}"
			// });	
			// var point15 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point15XValue}",   
			// 	y: "{/data/emp/point15YValue}"
			// });	
			// var point16 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point16XValue}",    
			// 	y: "{/data/emp/point16YValue}"
			// });	
			// var point17 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point17XValue}",
			// 	y: "{/data/emp/point17YValue}"
			// });	
			// var point18 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point18XValue}", 
			// 	y: "{/data/emp/point18YValue}"
			// });
			// var point19 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point19XValue}", 
			// 	y: "{/data/emp/point19YValue}"
			// });
			// var point20 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point20XValue}",  
			// 	y: "{/data/emp/point20YValue}"
			// });	
			// var point21 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point21XValue}",   
			// 	y: "{/data/emp/point21YValue}"
			// });	
			// var point22 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point22XValue}", 
			// 	y: "{/data/emp/point22YValue}"
			// });	
			// var point23 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point23XValue}", 
			// 	y: "{/data/emp/point23YValue}"
			// });	
			// var point24 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point24XValue}", 
			// 	y: "{/data/emp/point24YValue}"
			// });		
			// var point25 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point25XValue}", 
			// 	y: "{/data/emp/point25YValue}"
			// });
			// var point26 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point26XValue}", 
			// 	y: "{/data/emp/point26YValue}"
			// });	
			// var point27 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point27XValue}", 
			// 	y: "{/data/emp/point27YValue}"
			// });	
			// var point28 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point28XValue}", 
			// 	y: "{/data/emp/point28YValue}"
			// });	
			// var point29 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point29XValue}", 
			// 	y: "{/data/emp/point29YValue}"
			// });	
			// var point30 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point30XValue}", 
			// 	y: "{/data/emp/point30YValue}"
			// });
			// var point31 = new sap.suite.ui.microchart.LineMicroChartPoint({
			// 	x: "{/data/emp/point31XValue}", 
			// 	y: "{/data/emp/point31YValue}"
			// });		

			var point1 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point1XValue}",
				y: "{/data/emp/point1YValue}"
			});
			var point2 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point2XValue}",
				y: "{/data/emp/point2YValue}"
			});
			var point3 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point3XValue}",
				y: "{/data/emp/point3YValue}"
			});
			var point4 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point4XValue}",
				y: "{/data/emp/point4YValue}"
			});
			var point5 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point5XValue}",
				y: "{/data/emp/point5YValue}"
			});
			var point6 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point6XValue}",
				y: "{/data/emp/point6YValue}"
			});
			var point7 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point7XValue}",
				y: "{/data/emp/point7YValue}"
			});
			var point8 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point8XValue}",
				y: "{/data/emp/point8YValue}"
			});			
			var point9 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point9XValue}",
				y: "{/data/emp/point9YValue}"
			});
			var point10 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point10XValue}",
				y: "{/data/emp/point10YValue}"
			});
			var point11 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point11XValue}",
				y: "{/data/emp/point11YValue}"
			});
			var point12 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point12XValue}",
				y: "{/data/emp/point12YValue}"
			});
			var point13 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point13XValue}",
				y: "{/data/emp/point13YValue}"
			});
			var point14 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point14XValue}",
				y: "{/data/emp/point14YValue}"
			});
			var point15 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point15XValue}",
				y: "{/data/emp/point15YValue}"
			});
			var point16 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point16XValue}",
				y: "{/data/emp/point16YValue}"
			});			
			var point17 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point17XValue}",
				y: "{/data/emp/point17YValue}"
			});
			var point18 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point18XValue}",
				y: "{/data/emp/point18YValue}"
			});
			var point19 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point19XValue}",
				y: "{/data/emp/point19YValue}"
			});
			var point20 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point20XValue}",
				y: "{/data/emp/point20YValue}"
			});
			var point21 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point21XValue}",
				y: "{/data/emp/point21YValue}"
			});
			var point22 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point22XValue}",
				y: "{/data/emp/point22YValue}"
			});
			var point23 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point23XValue}",
				y: "{/data/emp/point23YValue}"
			});
			var point24 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point24XValue}",
				y: "{/data/emp/point24YValue}"
			});
			var point25 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point25XValue}",
				y: "{/data/emp/point25YValue}"
			});
			var point26 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point26XValue}",
				y: "{/data/emp/point26YValue}"
			});
			var point27 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point27XValue}",
				y: "{/data/emp/point27YValue}"
			});
			var point28 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point28XValue}",
				y: "{/data/emp/point28YValue}"
			});
			var point29 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point29XValue}",
				y: "{/data/emp/point29YValue}"
			});
			var point30 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point30XValue}",
				y: "{/data/emp/point30YValue}"
			});
			var point31 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/point31XValue}",
				y: "{/data/emp/point31YValue}"
			});			

			var target1 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target1XValue}",
				y: "{/data/emp/target1YValue}"
			});
			var target2 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target2XValue}",
				y: "{/data/emp/target2YValue}"
			});
			var target3 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target3XValue}",
				y: "{/data/emp/target3YValue}"
			});
			var target4 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target4XValue}",
				y: "{/data/emp/target4YValue}"
			});
			var target5 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target5XValue}",
				y: "{/data/emp/target5YValue}"
			});
			var target6 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target6XValue}",
				y: "{/data/emp/target6YValue}"
			});
			var target7 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target7XValue}",
				y: "{/data/emp/target7YValue}"
			});
			var target8 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target8XValue}",
				y: "{/data/emp/target8YValue}"
			});
			var target9 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target9XValue}",
				y: "{/data/emp/target9YValue}"
			});
			var target10 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target10XValue}",
				y: "{/data/emp/target10YValue}"
			});
			var target11 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target11XValue}",
				y: "{/data/emp/target11YValue}"
			});
			var target12 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target12XValue}",
				y: "{/data/emp/target12YValue}"
			});
			var target13 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target13XValue}",
				y: "{/data/emp/target13YValue}"
			});
			var target14 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target14XValue}",
				y: "{/data/emp/target14YValue}"
			});
			var target15 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target15XValue}",
				y: "{/data/emp/target15YValue}"
			});
			var target16 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target16XValue}",
				y: "{/data/emp/target16YValue}"
			});						
			var target17 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target17XValue}",
				y: "{/data/emp/target17YValue}"
			});
			var target18 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target18XValue}",
				y: "{/data/emp/target18YValue}"
			});
			var target19 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target19XValue}",
				y: "{/data/emp/target19YValue}"
			});
			var target20 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target20XValue}",
				y: "{/data/emp/target20YValue}"
			});
			var target21 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target21XValue}",
				y: "{/data/emp/target21YValue}"
			});
			var target22 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target22XValue}",
				y: "{/data/emp/target22YValue}"
			});
			var target23 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target23XValue}",
				y: "{/data/emp/target23YValue}"
			});
			var target24 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target24XValue}",
				y: "{/data/emp/target24YValue}"
			});
			var target25 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target25XValue}",
				y: "{/data/emp/target25YValue}"
			});
			var target26 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target26XValue}",
				y: "{/data/emp/target26YValue}"
			});
			var target27 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target27XValue}",
				y: "{/data/emp/target27YValue}"
			});
			var target28 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target28XValue}",
				y: "{/data/emp/target28YValue}"
			});
			var target29 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target29XValue}",
				y: "{/data/emp/target29YValue}"
			});
			var target30 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target30XValue}",
				y: "{/data/emp/target30YValue}"
			});
			var target31 = new sap.suite.ui.microchart.AreaMicroChartPoint({
				x: "{/data/emp/target31XValue}",
				y: "{/data/emp/target31YValue}"
			});			
			
			var firstXLabel = new sap.suite.ui.microchart.AreaMicroChartLabel({
				label: "{/data/emp/firstXLabel}"
			});
			var lastXLabel = new sap.suite.ui.microchart.AreaMicroChartLabel({
				label: "{/data/emp/lastXLabel}"
			});

			//var cc = {"above": "{/data/emp/colorAbove}", "below": "{/data/emp/colorBelow}"};
			/*			return new sap.m.CustomTile({
							content: [new sap.m.VBox({
								items: [ 
			                        new sap.m.Text({text:"{/data/display_title_text}"}),                        
									new	sap.m.Text({text:"{/data/display_subtitle_text}"}),
									new sap.suite.ui.microchart.ComparisonMicroChart({ 
										size:"M",
										data: [
											data1,
											data2,
											data3
									]  
									})
								]
							})],
							press: [oController.onPress, oController]
						});  */

			return new sap.m.GenericTile({
				header: '{/data/display_title_text}',
				subheader: '{/data/display_subtitle_text}',
				//                size: "Auto",   
				frameType: "TwoByOne", //TwoByOne
				tileContent: [new sap.m.TileContent({
						//						size: "Auto",
						footer: '{/data/emp/footer1}',
						unit: '{/data/emp/unit1}',
						//We'll utilize NumericContent for the "Dynamic" content.
						content: [
							new sap.m.NumericContent({
								scale: '{/data/display_number_factor}',
								value: '{/data/display_number_value}',
								truncateValueTo: 5, //Otherwise, The default value is 4.
								indicator: '{/data/display_state_arrow}',
								valueColor: '{/data/display_number_state}',
								icon: '{/data/display_icon_url}',
								width: '100%'

							})

							//						new sap.suite.ui.microchart.ComparisonMicroChart({
							//							scale: "M",
							//							footer: "Actual and Target",
							//							data: [
							//								data1,
							//								data2,
							//								data3
							//							]
							//						})

						]
					}),

					new sap.m.TileContent({
						// size: "Auto",  
						//                  footer: '{/data/display_info_text}',
						//                unit: '{/data/display_number_unit}',
						footer: '{/data/emp/footer2}',
						unit: '{/data/emp/unit2}',
						//We'll utilize NumericContent for the "Dynamic" content.
						content: [

							//							new sap.suite.ui.microchart.DeltaMicroChart({
							//								value1: '{/data/emp/value1}',
							//								value2: '{/data/emp/value2}',
							//								title1: '{/data/emp/title1}',
							//								title2: '{/data/emp/title2}',
							//								displayValue1: '{/data/emp/displayValue1}',
							//								displayValue2: '{/data/emp/displayValue2}',
							//								deltaDisplayValue: '{/data/emp/deltaDisplayValue}',
							//								color: '{/data/emp/color}'
							//							})

							//							new sap.suite.ui.microchart.BulletMicroChart({
							//								scale: "2",//'{/data/emp/scale}',
							//								targetValue: '{/data/emp/targetValue}',
							//						        targetValueLabel: '{/data/emp/targetValueLabel}',
							//						        minValue: '{/data/emp/minValue}',
							//						        maxValue: '{/data/emp/maxValue}',
							//						        actual: [actual]
							//	//					        thresholds : [threshold1,threshold2,threshold3,threshold4]
							//							})
							//            new sap.suite.ui.microchart.DeltaMicroChart({
							//        	value1:"1.5",
							//	value2:"1.0", title1:"May 2014", title2:"May 2013", displayValue1:"1.5 %",
							//	displayValue2:"1.0 %", deltaDisplayValue:"+ 0.5 %", color:"Error"
							//      })
							//					new sap.suite.ui.microchart.ColumnMicroChart({
							//						leftTopLabel : lefttoplabel,
							//						rightTopLabel : righttoplabel,
							//				        columns: [column1,column2,column3,column4,column5,column6,column7,column8,column9,column10,column11,column12]
							//					})	
							// new sap.suite.ui.microchart.LineMicroChart({
							// 	threshold: "{/data/emp/threshold}",
							// 	size: "Responsive",  //"Auto"
							// 	showPoints: "{/data/emp/showPoints}",
							// 	leftBottomLabel: "{/data/emp/leftBottomLabel}", 
							// 	rightBottomLabel: "{/data/emp/rightBottomLabel}",	
							// 	minXValue:"{/data/emp/minXValue}",
							// 	maxXValue:"{/data/emp/maxXValue}",
							// 	minYValue:"{/data/emp/minYValue}",
							// 	maxYValue:"{/data/emp/maxYValue}",
							// 	color: "{/data/emp/color}",							    
							//       points: [point1,point2,point3,point4,point5,point6,point7,point8,point9,point10,point11,point12,
							//                point13,point14,point15,point16,point17,point18,point19,point20,point21,point22,point23,point24,
							//                point25,point26,point27,point28,point29,point30,point31]
							// })	

							new sap.suite.ui.microchart.AreaMicroChart({
								//		size:"M",

								width: "144px",
								height: "78px",
								//				colorPalette:"#5cbae6, #b6d957, #fac364, #8cd3ff",
								colorPalette: "#5cbae6",

								minXValue: "{/data/emp/minXValue}",
								maxXValue: "{/data/emp/maxXValue}",
								minYValue: "{/data/emp/minYValue}",
								maxYValue: "{/data/emp/maxYValue}",
								firstXLabel: [firstXLabel],
								lastXLabel: [lastXLabel],
								lines: [new sap.suite.ui.microchart.AreaMicroChartItem({
									points: [point1, point2, point3, point4, point5, point6, point7, point8,
									         point9, point10, point11, point12, point13, point14, point15, point16,
									         point17, point18, point19, point20, point21, point22, point23, point24,
									         point25, point26, point27, point28, point29, point30, point31]
								})],
								target: [new sap.suite.ui.microchart.AreaMicroChartItem({

									points: [target1, target2, target3, target4, target5, target6, target7, target8,
									         target9, target10, target11, target12, target13, target14, target15, target16,
									         target17, target18, target19, target20, target21, target22, target23, target24,
									         target25, target26, target27, target28, target29, target30, target31]
								})]
							})

						]
					})
				],
				press: [oController.onPress, oController]
			});

			// return new sap.m.VBox({
			// 	content: [new sap.m.Label({text:'{/data/display_title_text}'})],
			// 	press: [oController.onPress, oController]
			// });
			// return new sap.m.GenericTile({
			// 	header: '{/data/display_title_text} - {/data/ztest}',
			// 	subheader: '{/data/display_subtitle_text}',
			// 	size: "Auto",
			// 	tileContent: [new sap.m.TileContent({
			// 		size: "Auto",
			// 		footer: '{/data/display_info_text}',
			// 		unit: '{/data/display_number_unit}',
			// 		//We'll utilize NumericContent for the "Dynamic" content.
			// 		content: [
			// new sap.m.NumericContent({
			// 	scale: '{/data/display_number_factor}',
			// 	value: '{/data/display_number_value}',
			// 	truncateValueTo: 5, //Otherwise, The default value is 4.
			// 	indicator: '{/data/display_state_arrow}',
			// 	valueColor: '{/data/display_number_state}',
			// 	icon: '{/data/display_icon_url}',
			// 	width: '100%'
			// })
			// ]
			// 	})],
			// 	press: [oController.onPress, oController]
			// });
		},
		getLinkControl: function () {
			jQuery.sap.require('sap.m.Link');

			return new sap.m.Link({
				text: "{/config/display_title_text}",
				href: "{/nav/navigation_target_url}"
			});
		}
	});
}());