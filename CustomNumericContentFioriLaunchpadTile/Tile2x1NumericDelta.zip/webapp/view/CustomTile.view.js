// Copyright (c) 2009-2014 SAP SE, All Rights Reserved

(function() {
	"use strict";
	/*global jQuery, sap */
	/*jslint nomen: true */

	sap.ui.jsview("view.CustomTile", {
		getControllerName: function() {
			return "view.CustomTile";
		},
		createContent: function(oController) {
			this.setHeight('100%');
			this.setWidth('100%');
		},
		getTileControl: function() {
			jQuery.sap.require('sap.m.GenericTile');
			jQuery.sap.require('sap.suite.ui.microchart.ComparisonMicroChart');
			jQuery.sap.require('sap.suite.ui.microchart.DeltaMicroChart');
//			jQuery.sap.require('sap.suite.ui.commons.NumericContent');

			var oController = this.getController();
			var itemTemplate = new sap.m.StandardListItem({
				icon: "{Icon}",
				/*				description:"{Naam}",  */
				title: "{Naam}"
			});

			var data1 = new sap.suite.ui.microchart.ComparisonMicroChartData({
				title: "{/data/emp/month1}",
				value: "{/data/emp/value1}",
				/*10*/
				color: "{/data/emp/color1}"
			});
			var data2 = new sap.suite.ui.microchart.ComparisonMicroChartData({
				title: "{/data/emp/month2}",
				value: "{/data/emp/value2}",
				/*20*/
				color: "{/data/emp/color2}"
			});
			var data3 = new sap.suite.ui.microchart.ComparisonMicroChartData({
				title: "{/data/emp/month3}",
				value: "{/data/emp/value3}",
				/*-10, */
				color: "{/data/emp/color3}"
			});

			/*			return new sap.m.CustomTile({
							content: [new sap.m.VBox({
								items: [ 
			                        new sap.m.Text({text:"{/data/display_title_text}"}),                        
									new	sap.m.Text({text:"{/data/display_subtitle_text}"}),
									new sap.suite.ui.microchart.ComparisonMicroChart({ 
										size:"M",
										data: [
											data1,
											data2,
											data3
									]  
									})
								]
							})],
							press: [oController.onPress, oController]
						});  */

			return new sap.m.GenericTile({
				header: '{/data/display_title_text}',
				subheader: '{/data/display_subtitle_text}',
				//                size: "Auto",   
				frameType: "TwoByOne", //TwoByOne
				tileContent: [new sap.m.TileContent({
//						size: "Auto",
						footer: '{/data/emp/footer1}',
						unit: '{/data/emp/unit1}',
						//We'll utilize NumericContent for the "Dynamic" content.
						content: [
							new sap.m.NumericContent({
								scale: '{/data/display_number_factor}',
								value: '{/data/display_number_value}',
								truncateValueTo: 5, //Otherwise, The default value is 4.
								indicator: '{/data/display_state_arrow}',
								valueColor: '{/data/display_number_state}',
								icon: '{/data/display_icon_url}',
								width: '100%'

							})

							//						new sap.suite.ui.microchart.ComparisonMicroChart({
							//							scale: "M",
							//							footer: "Actual and Target",
							//							data: [
							//								data1,
							//								data2,
							//								data3
							//							]
							//						})

						]
					}),

					new sap.m.TileContent({
						// size: "Auto",  
						//                  footer: '{/data/display_info_text}',
						//                unit: '{/data/display_number_unit}',
						footer: '{/data/emp/footer2}',
						unit: '{/data/emp/unit2}',
						//We'll utilize NumericContent for the "Dynamic" content.
						content: [

							new sap.suite.ui.microchart.DeltaMicroChart({
								value1: '{/data/emp/value1}',
								value2: '{/data/emp/value2}',
								title1: '{/data/emp/title1}',
								title2: '{/data/emp/title2}',
								displayValue1: '{/data/emp/displayValue1}',
								displayValue2: '{/data/emp/displayValue2}',
								deltaDisplayValue: '{/data/emp/deltaDisplayValue}',
								color: '{/data/emp/color}'
							})
							//            new sap.suite.ui.microchart.DeltaMicroChart({
							//        	value1:"1.5",
							//	value2:"1.0", title1:"May 2014", title2:"May 2013", displayValue1:"1.5 %",
							//	displayValue2:"1.0 %", deltaDisplayValue:"+ 0.5 %", color:"Error"
							//      })

						]
					})
				],
				press: [oController.onPress, oController]
			});

			// return new sap.m.VBox({
			// 	content: [new sap.m.Label({text:'{/data/display_title_text}'})],
			// 	press: [oController.onPress, oController]
			// });
			// return new sap.m.GenericTile({
			// 	header: '{/data/display_title_text} - {/data/ztest}',
			// 	subheader: '{/data/display_subtitle_text}',
			// 	size: "Auto",
			// 	tileContent: [new sap.m.TileContent({
			// 		size: "Auto",
			// 		footer: '{/data/display_info_text}',
			// 		unit: '{/data/display_number_unit}',
			// 		//We'll utilize NumericContent for the "Dynamic" content.
			// 		content: [
			// new sap.m.NumericContent({
			// 	scale: '{/data/display_number_factor}',
			// 	value: '{/data/display_number_value}',
			// 	truncateValueTo: 5, //Otherwise, The default value is 4.
			// 	indicator: '{/data/display_state_arrow}',
			// 	valueColor: '{/data/display_number_state}',
			// 	icon: '{/data/display_icon_url}',
			// 	width: '100%'
			// })
			// ]
			// 	})],
			// 	press: [oController.onPress, oController]
			// });
		},
		getLinkControl: function() {
			jQuery.sap.require('sap.m.Link');

			return new sap.m.Link({
				text: "{/config/display_title_text}",
				href: "{/nav/navigation_target_url}"
			});
		}
	});
}());