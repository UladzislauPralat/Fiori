// Copyright (c) 2009-2014 SAP SE, All Rights Reserved

(function() {
	"use strict";
	/*global jQuery, sap */
	/*jslint nomen: true */

	sap.ui.jsview("view.CustomTile4", {
		getControllerName: function() {
			return "view.CustomTile4";
		},
		createContent: function(oController) {
			this.setHeight('100%');
			this.setWidth('100%');
		},
		getTileControl: function() {
			jQuery.sap.require('sap.m.GenericTile');
			jQuery.sap.require('sap.suite.ui.microchart.ComparisonMicroChart');
//			jQuery.sap.require('sap.suite.ui.microchart.DeltaMicroChart');
//			jQuery.sap.require('sap.suite.ui.microchart.BulletMicroChart');
//			jQuery.sap.require('sap.suite.ui.microchart.ColumnMicroChart');			
//			jQuery.sap.require('sap.suite.ui.commons.NumericContent');

			var oController = this.getController();
//			var itemTemplate = new sap.m.StandardListItem({
//				icon: "{Icon}",
//				/*				description:"{Naam}",  */
//				title: "{Naam}"
//			});

			var data1 = new sap.suite.ui.microchart.ComparisonMicroChartData({
				title: "{/data/emp/title1}", //"Example 1"
				value: "{/data/emp/value1}", //25
				color: "{/data/emp/color1}"  //"Neutral"
			});
			var data2 = new sap.suite.ui.microchart.ComparisonMicroChartData({
				title: "{/data/emp/title2}", //"Example 2"
				value: "{/data/emp/value2}", //15
				color: "{/data/emp/color2}"  //"Good"
			});
			var data3 = new sap.suite.ui.microchart.ComparisonMicroChartData({
				title: "{/data/emp/title3}", //"Example 3"
				value: "{/data/emp/value3}", //35
				color: "{/data/emp/color3}" //"Error" 
			});


//			var actual = new sap.suite.ui.microchart.BulletMicroChartData({
//				value: '{/data/emp/actual}',
//				color: '{/data/emp/color}'
//			});

//          var leftbottomlabel = new sap.suite.ui.microchart.ColumnMicroChartLabel({
//			label : "28",
//			color : "Error"
//			});			
//           var rightbottomlabel = new sap.suite.ui.microchart.ColumnMicroChartLabel({
//			label : "27",
//			color : "Error"
//			});						

		
			/*			return new sap.m.CustomTile({
							content: [new sap.m.VBox({
								items: [ 
			                        new sap.m.Text({text:"{/data/display_title_text}"}),                        
									new	sap.m.Text({text:"{/data/display_subtitle_text}"}),
									new sap.suite.ui.microchart.ComparisonMicroChart({ 
										size:"M",
										data: [
											data1,
											data2,
											data3
									]  
									})
								]
							})],
							press: [oController.onPress, oController]
						});  */

			return new sap.m.GenericTile({
				header: '{/data/display_title_text}',
				subheader: '{/data/display_subtitle_text}',
				//                size: "Auto",   
				frameType: "OneByOne", //TwoByOne
				tileContent: [new sap.m.TileContent({
//						size: "Auto",
						footer: "{/data/emp/footer}",
						unit: "{/data/emp/unit}", 
						//We'll utilize NumericContent for the "Dynamic" content.
						content: [
//							new sap.m.NumericContent({
//								scale: '{/data/display_number_factor}',
//								value: '{/data/display_number_value}',
//								truncateValueTo: 5, //Otherwise, The default value is 4.
//								indicator: '{/data/display_state_arrow}',
//								valueColor: '{/data/display_number_state}',
//								icon: '{/data/display_icon_url}',
//								width: '100%'
//
//							})
							new sap.suite.ui.microchart.ComparisonMicroChart({ 
								size:"M",
								data: [
									data1,
									data2,
									data3
								]  
							})		
							//						new sap.suite.ui.microchart.ComparisonMicroChart({
							//							scale: "M",
							//							footer: "Actual and Target",
							//							data: [
							//								data1,
							//								data2,
							//								data3
							//							]
							//						})

						]
					})
				],
				press: [oController.onPress, oController]
			});

			// return new sap.m.VBox({
			// 	content: [new sap.m.Label({text:'{/data/display_title_text}'})],
			// 	press: [oController.onPress, oController]
			// });
			// return new sap.m.GenericTile({
			// 	header: '{/data/display_title_text} - {/data/ztest}',
			// 	subheader: '{/data/display_subtitle_text}',
			// 	size: "Auto",
			// 	tileContent: [new sap.m.TileContent({
			// 		size: "Auto",
			// 		footer: '{/data/display_info_text}',
			// 		unit: '{/data/display_number_unit}',
			// 		//We'll utilize NumericContent for the "Dynamic" content.
			// 		content: [
			// new sap.m.NumericContent({
			// 	scale: '{/data/display_number_factor}',
			// 	value: '{/data/display_number_value}',
			// 	truncateValueTo: 5, //Otherwise, The default value is 4.
			// 	indicator: '{/data/display_state_arrow}',
			// 	valueColor: '{/data/display_number_state}',
			// 	icon: '{/data/display_icon_url}',
			// 	width: '100%'
			// })
			// ]
			// 	})],
			// 	press: [oController.onPress, oController]
			// });
		},
		getLinkControl: function() {
			jQuery.sap.require('sap.m.Link');

			return new sap.m.Link({
				text: "{/config/display_title_text}",
				href: "{/nav/navigation_target_url}"
			});
		}
	});
}());